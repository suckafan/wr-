type StatusType = "UPDATED" | "DELAYED" | "WORKING ON DEVELOPMENT";

const status: StatusType = "WORKING ON DEVELOPMENT";

const statusConfig = {
  UPDATED: {
    label: "UPDATED",
    color: "text-emerald-500",
    dotColor: "bg-emerald-500",
    borderColor: "border-emerald-500/50",
  },
  DELAYED: {
    label: "DELAYED",
    color: "text-rose-500",
    dotColor: "bg-rose-500",
    borderColor: "border-rose-500/50",
  },
  "WORKING ON DEVELOPMENT": {
    label: "WORKING ON DEVELOPMENT",
    color: "text-amber-500",
    dotColor: "bg-amber-500",
    borderColor: "border-amber-500/50",
  },
};

export default function StatusPanel() {
  const config = statusConfig[status];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <div className={`glassmorphism border ${config.borderColor} rounded-lg p-4 flex items-center gap-3`}>
        <span className="uppercase-wide text-xs font-semibold text-zinc-400">
          Progress Status:
        </span>
        <div className="flex items-center gap-2">
          <div className="relative">
            <div className={`${config.dotColor} pulse-dot w-3 h-3 rounded-full`} />
            <div className={`absolute inset-0 ${config.dotColor} ping-dot w-3 h-3 rounded-full`} />
          </div>
          <span className={`uppercase-wide text-xs font-bold ${config.color}`}>
            {config.label}
          </span>
        </div>
      </div>
    </div>
  );
}
