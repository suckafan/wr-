import { Outlet } from "react-router-dom";
import Navbar from "./Navbar";
import StatusPanel from "./StatusPanel";

export default function Layout() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-950 via-zinc-950 to-zinc-900">
      <Navbar />

      {/* Hero Section */}
      <div className="relative h-72 sm:h-80 md:h-96 overflow-hidden bg-gradient-to-b from-zinc-900 to-zinc-950">
        <img
          src="https://images.unsplash.com/photo-1534274988757-a28bf1ad0e1f?w=1600&h=600&fit=crop"
          alt=""
          className="absolute inset-0 w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/5 via-transparent to-zinc-950" />

        <div className="relative h-full flex items-center justify-start px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold uppercase-wide">
              <span className="text-zinc-200">[</span>
              <span className="text-emerald-500"> Development Hub </span>
              <span className="text-zinc-200">]</span>
            </h1>
            <p className="mt-4 text-sm sm:text-base text-zinc-300 uppercase-wide tracking-wide">
              Tracking features, fixes, and storm activity
            </p>
          </div>
        </div>
      </div>

      <StatusPanel />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs uppercase-wide text-zinc-500">
          <p>Simulation Engine • Build version Alpha</p>
        </div>
      </footer>
    </div>
  );
}
