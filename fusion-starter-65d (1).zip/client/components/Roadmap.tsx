import {
  Radar as RadarIcon,
  Cloud,
  Tornado,
  AlertTriangle,
  Zap,
} from "lucide-react";

const roadmapCategories = [
  {
    id: "radar",
    title: "Radar Systems & Visualization",
    icon: RadarIcon,
    items: [
      "Add radar product selector",
      "Implement hail indicator icons",
      "TVS (Tornado Vortex Signature) scaling",
      "Velocity couplet visualization",
      "Echo top height calculations",
      "Storm-relative velocity display",
      "Spectrum width analysis tool",
      "Advanced radar filtering options",
    ],
  },
  {
    id: "storm",
    title: "Storm Simulation & Environment",
    icon: Cloud,
    items: [
      "Spotter report integration",
      "Tornadogenesis triggers",
      "Thermodynamic modeling",
      "Wind shear calculations",
      "Moisture convergence zones",
      "Temperature advection display",
    ],
  },
  {
    id: "tornado",
    title: "Tornado Tracking & Analysis",
    icon: Tornado,
    items: [
      "Track visualization layer",
      "Damage path mapping",
      "Analysis menu implementation",
      "Historical comparison tools",
    ],
  },
  {
    id: "warnings",
    title: "Warnings & Scoring System",
    icon: AlertTriangle,
    items: [
      "Point-based reward system",
      "Abuse prevention mechanisms",
      "Dynamic warning text generation",
      "Performance metrics dashboard",
    ],
  },
  {
    id: "future",
    title: "Low Priority / Future Possibilities",
    icon: Zap,
    items: [
      "Multiplayer features (not priority)",
      "Leaderboard system",
      "Custom scenario builder",
      "API integrations for real-time data",
    ],
  },
];

export default function Roadmap() {
  return (
    <div className="space-y-8 animate-fade-in">
      <div className="mb-8">
        <h2 className="text-2xl md:text-3xl uppercase-wide font-bold text-emerald-500 mb-2">
          [ Development Roadmap ]
        </h2>
        <p className="text-zinc-400 uppercase-wide text-xs">
          Planned features and enhancements
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {roadmapCategories.map((category, idx) => {
          const Icon = category.icon;
          return (
            <div
              key={category.id}
              className="glassmorphism glow-emerald rounded-lg p-6 border-2 animate-fade-in opacity-0"
              style={{
                animation: `fadeIn 0.5s ease-out ${idx * 0.1}s forwards`,
              }}
            >
              <div className="flex items-center gap-3 mb-4">
                <Icon className="w-6 h-6 text-emerald-500" />
                <h3 className="text-lg uppercase-wide font-bold text-zinc-200">
                  {category.title}
                </h3>
              </div>

              <ul className="space-y-3">
                {category.items.map((item, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-3 text-sm text-zinc-300"
                  >
                    <span className="text-emerald-500 font-bold mt-1">▸</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
}
