import { Link, useLocation } from "react-router-dom";
import { CloudLightning, Radar, Bug } from "lucide-react";

export default function Navbar() {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="sticky top-0 z-50 glassmorphism border-b border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2 hover:text-emerald-500 transition-colors">
            <CloudLightning className="w-6 h-6 text-emerald-500" />
            <span className="uppercase-wide text-sm font-bold">WarnGen</span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            <Link
              to="/"
              className={`uppercase-wide text-xs font-semibold flex items-center gap-2 pb-2 border-b-2 transition-colors ${
                isActive("/")
                  ? "text-emerald-500 border-emerald-500"
                  : "text-zinc-400 border-transparent hover:text-zinc-200"
              }`}
            >
              <Radar className="w-4 h-4" />
              Roadmap
            </Link>
            <Link
              to="/bugs"
              className={`uppercase-wide text-xs font-semibold flex items-center gap-2 pb-2 border-b-2 transition-colors ${
                isActive("/bugs")
                  ? "text-emerald-500 border-emerald-500"
                  : "text-zinc-400 border-transparent hover:text-zinc-200"
              }`}
            >
              <Bug className="w-4 h-4" />
              Known Issues & Fixes
            </Link>
          </div>

          <div className="md:hidden">
            <Link
              to="/"
              className={`px-3 py-2 rounded-md text-xs font-semibold uppercase-wide ${
                isActive("/")
                  ? "text-emerald-500 bg-zinc-900"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              Roadmap
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
