import { CheckCircle2, CircleDashed } from "lucide-react";

interface BugItem {
  id: string;
  title: string;
  description: string;
  status: "completed" | "pending";
}

const bugs: BugItem[] = [
  {
    id: "1",
    title: "Save System Data Loss",
    description: "User progress not persisting across sessions in certain conditions",
    status: "pending",
  },
  {
    id: "2",
    title: "In-Game Save Loading",
    description: "Saved games fail to load with 'corrupted data' error message",
    status: "pending",
  },
  {
    id: "3",
    title: "Environment Reset on Load",
    description:
      "Storm environment resets when loading a saved game instead of restoring state",
    status: "pending",
  },
  {
    id: "4",
    title: "Storm Persistence",
    description: "Active storms disappear when switching between radar products",
    status: "pending",
  },
  {
    id: "5",
    title: "High Risk Outlook Rendering",
    description: "SPC High Risk areas render with incorrect polygon coordinates",
    status: "pending",
  },
  {
    id: "6",
    title: "Warning Polygon UI State",
    description: "Warning polygons not updating properly when warning is extended",
    status: "pending",
  },
  {
    id: "7",
    title: "Warning Text Alignment",
    description: "Warning text overlaps with other UI elements on small screens",
    status: "pending",
  },
  {
    id: "8",
    title: "Duplicate Warning Point Farming",
    description: "Players can game the system by issuing duplicate warnings",
    status: "pending",
  },
  {
    id: "9",
    title: "Dynamic Intensity Indicators",
    description: "Storm intensity labels not updating in real-time during simulation",
    status: "pending",
  },
];

export default function BugFixes() {
  return (
    <div className="space-y-8">
      <div className="mb-8">
        <h2 className="text-2xl md:text-3xl uppercase-wide font-bold text-rose-500 mb-2">
          [ Known Issues & Fixes ]
        </h2>
        <p className="text-zinc-400 uppercase-wide text-xs">
          {bugs.length} issues tracked in development
        </p>
      </div>

      <div className="space-y-3">
        {bugs.map((bug, idx) => (
          <div
            key={bug.id}
            className="glassmorphism border-l-4 border-l-rose-500 rounded-lg p-4 hover:border-l-rose-400 transition-colors opacity-0 animate-fade-in"
            style={{
              animation: `fadeInLeft 0.4s ease-out ${idx * 0.05}s forwards`,
            }}
          >
            <div className="flex items-start gap-3">
              {bug.status === "completed" ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
              ) : (
                <CircleDashed className="w-5 h-5 text-rose-500 flex-shrink-0 mt-0.5" />
              )}

              <div className="flex-1 min-w-0">
                <h3 className="text-sm md:text-base uppercase-wide font-semibold text-zinc-200">
                  {bug.title}
                </h3>
                <p className="mt-1 text-xs md:text-sm text-zinc-400">
                  {bug.description}
                </p>
              </div>

              <div className="flex-shrink-0">
                <span
                  className={`inline-block px-2 py-1 rounded text-xs uppercase-wide font-bold ${
                    bug.status === "completed"
                      ? "bg-emerald-500/20 text-emerald-400"
                      : "bg-rose-500/20 text-rose-400"
                  }`}
                >
                  {bug.status === "completed" ? "Fixed" : "Pending"}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
