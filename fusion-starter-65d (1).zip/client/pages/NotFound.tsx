import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center px-4">
      <div className="text-center">
        <AlertTriangle className="w-16 h-16 mx-auto text-rose-500 mb-6" />
        <h1 className="text-5xl md:text-6xl font-bold uppercase-wide text-zinc-200 mb-2">
          [ 404 ]
        </h1>
        <p className="text-lg md:text-xl uppercase-wide text-zinc-400 mb-6">
          Page not found
        </p>
        <p className="text-zinc-500 text-sm mb-8 max-w-sm mx-auto">
          The requested route "{location.pathname}" does not exist in our system.
        </p>
        <Link
          to="/"
          className="inline-block px-6 py-3 bg-emerald-500 text-zinc-950 font-bold uppercase-wide text-sm rounded hover:bg-emerald-400 transition-colors"
        >
          Return to Roadmap
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
